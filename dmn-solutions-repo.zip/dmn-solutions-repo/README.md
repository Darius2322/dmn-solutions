# DMN Solutions

Monorepo with two independent Next.js apps, deployed separately:

- **/public-app** — the public-facing site (see `public-app/README.md`)
- **/admin-app** — standalone admin dashboard, deploy to its own domain
  (see `admin-app/README.md`)

Both share one Supabase project. Database migrations live in
`public-app/supabase/migrations/` as the single source of truth.

Each app has its own `package.json` — install and run them independently:

```bash
cd public-app && npm install && npm run dev
cd admin-app && npm install && npm run dev   # runs on :3001
```
